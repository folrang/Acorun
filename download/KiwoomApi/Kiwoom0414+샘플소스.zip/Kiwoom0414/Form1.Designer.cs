﻿namespace Kiwoom0414
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
                 
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.axKHOpenAPI = new AxKHOpenAPILib.AxKHOpenAPI();
            this.Label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl이름 = new System.Windows.Forms.Label();
            this.lbl아이디 = new System.Windows.Forms.Label();
            this.cbo계좌 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt종목코드 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbo거래구분 = new System.Windows.Forms.ComboBox();
            this.btn주문 = new System.Windows.Forms.Button();
            this.cbo매매구분 = new System.Windows.Forms.ComboBox();
            this.txt원주문번호 = new System.Windows.Forms.TextBox();
            this.txt주문가격 = new System.Windows.Forms.TextBox();
            this.txt주문수량 = new System.Windows.Forms.TextBox();
            this.txt주문종목코드 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbo조건식 = new System.Windows.Forms.ComboBox();
            this.btn_조건실시간중지 = new System.Windows.Forms.Button();
            this.btn조건실시간조회 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btn자동주문 = new System.Windows.Forms.Button();
            this.lst실시간 = new System.Windows.Forms.ListBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.예수금1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.주문가능액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.유가잔고액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.총매수금액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.총매도금액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.매매수수료 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.매매세금 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.손익금 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.당일수익률 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.검색코드 = new System.Windows.Forms.ListBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbo조건식매도 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.btn화면번호초기화 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.종목코드 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.종목명 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.현재가 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.등락률 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.거래량 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.기호 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.보유수량 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.매입 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.평가금액 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.수익률 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.btn매도실시간조회 = new System.Windows.Forms.Button();
            this.lbl코스피 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button17 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.lbl현재시간 = new System.Windows.Forms.Label();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.lst매수미체결 = new System.Windows.Forms.ListBox();
            this.lst매도미체결 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // axKHOpenAPI
            // 
            this.axKHOpenAPI.Enabled = true;
            this.axKHOpenAPI.Location = new System.Drawing.Point(1339, 626);
            this.axKHOpenAPI.Name = "axKHOpenAPI";
            this.axKHOpenAPI.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI.OcxState")));
            this.axKHOpenAPI.Size = new System.Drawing.Size(80, 20);
            this.axKHOpenAPI.TabIndex = 11;
            this.axKHOpenAPI.OnReceiveTrData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEventHandler(this.axKHOpenAPI_OnReceiveTrData);
            this.axKHOpenAPI.OnReceiveRealData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEventHandler(this.axKHOpenAPI_OnReceiveRealData);
            this.axKHOpenAPI.OnReceiveMsg += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEventHandler(this.axKHOpenAPI_OnReceiveMsg);
            this.axKHOpenAPI.OnReceiveChejanData += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEventHandler(this.axKHOpenAPI_OnReceiveChejanData);
            this.axKHOpenAPI.OnEventConnect += new AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEventHandler(this.axKHOpenAPI_OnEventConnect);
            this.axKHOpenAPI.OnReceiveRealCondition += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealConditionEventHandler(this.axKHOpenAPI_OnReceiveRealCondition);
            this.axKHOpenAPI.OnReceiveTrCondition += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrConditionEventHandler(this.axKHOpenAPI_OnReceiveTrCondition);
            this.axKHOpenAPI.OnReceiveConditionVer += new AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveConditionVerEventHandler(this.axKHOpenAPI_OnReceiveConditionVer);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(1337, 584);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(41, 12);
            this.Label1.TabIndex = 12;
            this.Label1.Text = "이름 : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1337, 605);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "아이디 : ";
            // 
            // lbl이름
            // 
            this.lbl이름.AutoSize = true;
            this.lbl이름.Location = new System.Drawing.Point(1367, 581);
            this.lbl이름.Name = "lbl이름";
            this.lbl이름.Size = new System.Drawing.Size(0, 12);
            this.lbl이름.TabIndex = 14;
            // 
            // lbl아이디
            // 
            this.lbl아이디.AutoSize = true;
            this.lbl아이디.Location = new System.Drawing.Point(1383, 606);
            this.lbl아이디.Name = "lbl아이디";
            this.lbl아이디.Size = new System.Drawing.Size(0, 12);
            this.lbl아이디.TabIndex = 15;
            // 
            // cbo계좌
            // 
            this.cbo계좌.FormattingEnabled = true;
            this.cbo계좌.Location = new System.Drawing.Point(8, 616);
            this.cbo계좌.Name = "cbo계좌";
            this.cbo계좌.Size = new System.Drawing.Size(119, 20);
            this.cbo계좌.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "종목코드 :";
            // 
            // txt종목코드
            // 
            this.txt종목코드.Location = new System.Drawing.Point(73, 239);
            this.txt종목코드.Name = "txt종목코드";
            this.txt종목코드.Size = new System.Drawing.Size(54, 21);
            this.txt종목코드.TabIndex = 19;
            this.txt종목코드.Text = "114860";
            this.txt종목코드.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt종목코드_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbo거래구분);
            this.groupBox1.Controls.Add(this.btn주문);
            this.groupBox1.Controls.Add(this.cbo매매구분);
            this.groupBox1.Controls.Add(this.txt원주문번호);
            this.groupBox1.Controls.Add(this.txt주문가격);
            this.groupBox1.Controls.Add(this.txt주문수량);
            this.groupBox1.Controls.Add(this.txt주문종목코드);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(1068, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 216);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "주문입력";
            // 
            // cbo거래구분
            // 
            this.cbo거래구분.FormattingEnabled = true;
            this.cbo거래구분.Items.AddRange(new object[] {
            "지정가",
            "시장가",
            "조건부지정가",
            "최유리지정가",
            "최우선지정가",
            "지정가IOC",
            "시장가IOC",
            "최유리IOC",
            "지정가FOK",
            "시장가FOK",
            "최유리FOK",
            "장개시전시간외",
            "시간외단일가매매",
            "시간외종가"});
            this.cbo거래구분.Location = new System.Drawing.Point(84, 46);
            this.cbo거래구분.Name = "cbo거래구분";
            this.cbo거래구분.Size = new System.Drawing.Size(141, 20);
            this.cbo거래구분.TabIndex = 10;
            // 
            // btn주문
            // 
            this.btn주문.Location = new System.Drawing.Point(84, 178);
            this.btn주문.Name = "btn주문";
            this.btn주문.Size = new System.Drawing.Size(141, 30);
            this.btn주문.TabIndex = 12;
            this.btn주문.Text = "주     문";
            this.btn주문.UseVisualStyleBackColor = true;
            this.btn주문.Click += new System.EventHandler(this.btn주문_Click);
            // 
            // cbo매매구분
            // 
            this.cbo매매구분.FormattingEnabled = true;
            this.cbo매매구분.Items.AddRange(new object[] {
            "신규매수",
            "신규매도",
            "매수취소",
            "매도취소",
            "매수정정",
            "매도정정"});
            this.cbo매매구분.Location = new System.Drawing.Point(84, 70);
            this.cbo매매구분.Name = "cbo매매구분";
            this.cbo매매구분.Size = new System.Drawing.Size(141, 20);
            this.cbo매매구분.TabIndex = 11;
            // 
            // txt원주문번호
            // 
            this.txt원주문번호.Location = new System.Drawing.Point(84, 151);
            this.txt원주문번호.Name = "txt원주문번호";
            this.txt원주문번호.Size = new System.Drawing.Size(141, 21);
            this.txt원주문번호.TabIndex = 9;
            this.txt원주문번호.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt원주문번호_KeyPress);
            // 
            // txt주문가격
            // 
            this.txt주문가격.Location = new System.Drawing.Point(84, 124);
            this.txt주문가격.Name = "txt주문가격";
            this.txt주문가격.Size = new System.Drawing.Size(141, 21);
            this.txt주문가격.TabIndex = 8;
            this.txt주문가격.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt주문가격_KeyPress);
            // 
            // txt주문수량
            // 
            this.txt주문수량.Location = new System.Drawing.Point(84, 97);
            this.txt주문수량.Name = "txt주문수량";
            this.txt주문수량.Size = new System.Drawing.Size(141, 21);
            this.txt주문수량.TabIndex = 7;
            this.txt주문수량.Text = "10";
            this.txt주문수량.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt주문수량_KeyPress);
            // 
            // txt주문종목코드
            // 
            this.txt주문종목코드.Location = new System.Drawing.Point(84, 20);
            this.txt주문종목코드.Name = "txt주문종목코드";
            this.txt주문종목코드.Size = new System.Drawing.Size(141, 21);
            this.txt주문종목코드.TabIndex = 6;
            this.txt주문종목코드.Text = "039490";
            this.txt주문종목코드.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt주문종목코드_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 156);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 5;
            this.label11.Text = "원주문번호";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 131);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "주문가격";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "주문수량";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "매매구분";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "거래구분";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "종목코드";
            // 
            // cbo조건식
            // 
            this.cbo조건식.FormattingEnabled = true;
            this.cbo조건식.Location = new System.Drawing.Point(213, 625);
            this.cbo조건식.Name = "cbo조건식";
            this.cbo조건식.Size = new System.Drawing.Size(164, 20);
            this.cbo조건식.TabIndex = 23;
            // 
            // btn_조건실시간중지
            // 
            this.btn_조건실시간중지.BackColor = System.Drawing.Color.LightPink;
            this.btn_조건실시간중지.Location = new System.Drawing.Point(506, 622);
            this.btn_조건실시간중지.Name = "btn_조건실시간중지";
            this.btn_조건실시간중지.Size = new System.Drawing.Size(75, 51);
            this.btn_조건실시간중지.TabIndex = 27;
            this.btn_조건실시간중지.Text = "실시간중지";
            this.btn_조건실시간중지.UseVisualStyleBackColor = false;
            this.btn_조건실시간중지.Click += new System.EventHandler(this.btn_조건실시간중지_Click_1);
            // 
            // btn조건실시간조회
            // 
            this.btn조건실시간조회.BackColor = System.Drawing.Color.LightPink;
            this.btn조건실시간조회.Location = new System.Drawing.Point(381, 623);
            this.btn조건실시간조회.Name = "btn조건실시간조회";
            this.btn조건실시간조회.Size = new System.Drawing.Size(121, 23);
            this.btn조건실시간조회.TabIndex = 26;
            this.btn조건실시간조회.Text = "실시간조회 [매수]";
            this.btn조건실시간조회.UseVisualStyleBackColor = false;
            this.btn조건실시간조회.Click += new System.EventHandler(this.btn조건실시간조회_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.OrangeRed;
            this.label12.Location = new System.Drawing.Point(136, 628);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "매수조건식 : ";
            // 
            // btn자동주문
            // 
            this.btn자동주문.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn자동주문.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn자동주문.Location = new System.Drawing.Point(827, 623);
            this.btn자동주문.Name = "btn자동주문";
            this.btn자동주문.Size = new System.Drawing.Size(236, 51);
            this.btn자동주문.TabIndex = 26;
            this.btn자동주문.Text = "시스템 트레이딩 가동";
            this.btn자동주문.UseVisualStyleBackColor = false;
            this.btn자동주문.Click += new System.EventHandler(this.btn자동주문_Click_1);
            // 
            // lst실시간
            // 
            this.lst실시간.FormattingEnabled = true;
            this.lst실시간.ItemHeight = 12;
            this.lst실시간.Location = new System.Drawing.Point(383, 543);
            this.lst실시간.Name = "lst실시간";
            this.lst실시간.Size = new System.Drawing.Size(678, 76);
            this.lst실시간.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.예수금1,
            this.주문가능액,
            this.유가잔고액,
            this.총매수금액,
            this.총매도금액,
            this.매매수수료,
            this.매매세금,
            this.손익금,
            this.당일수익률});
            this.dataGridView2.Location = new System.Drawing.Point(138, 15);
            this.dataGridView2.Name = "dataGridView2";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.RowHeadersWidth = 21;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(924, 39);
            this.dataGridView2.TabIndex = 28;
            // 
            // 예수금1
            // 
            this.예수금1.HeaderText = "예수금";
            this.예수금1.Name = "예수금1";
            // 
            // 주문가능액
            // 
            this.주문가능액.HeaderText = "주문가능액";
            this.주문가능액.Name = "주문가능액";
            // 
            // 유가잔고액
            // 
            this.유가잔고액.HeaderText = "유가잔고액";
            this.유가잔고액.Name = "유가잔고액";
            // 
            // 총매수금액
            // 
            this.총매수금액.HeaderText = "당일매수액";
            this.총매수금액.Name = "총매수금액";
            // 
            // 총매도금액
            // 
            this.총매도금액.HeaderText = "당일매도액";
            this.총매도금액.Name = "총매도금액";
            // 
            // 매매수수료
            // 
            this.매매수수료.HeaderText = "매매수수료";
            this.매매수수료.Name = "매매수수료";
            // 
            // 매매세금
            // 
            this.매매세금.HeaderText = "매매세금";
            this.매매세금.Name = "매매세금";
            // 
            // 손익금
            // 
            this.손익금.HeaderText = "손익금";
            this.손익금.Name = "손익금";
            // 
            // 당일수익률
            // 
            this.당일수익률.HeaderText = "당일수익률";
            this.당일수익률.Name = "당일수익률";
            // 
            // 검색코드
            // 
            this.검색코드.FormattingEnabled = true;
            this.검색코드.ItemHeight = 12;
            this.검색코드.Location = new System.Drawing.Point(139, 461);
            this.검색코드.Name = "검색코드";
            this.검색코드.Size = new System.Drawing.Size(238, 160);
            this.검색코드.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label14.Location = new System.Drawing.Point(136, 657);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 12);
            this.label14.TabIndex = 32;
            this.label14.Text = "매도조건식 : ";
            // 
            // cbo조건식매도
            // 
            this.cbo조건식매도.FormattingEnabled = true;
            this.cbo조건식매도.Location = new System.Drawing.Point(213, 653);
            this.cbo조건식매도.Name = "cbo조건식매도";
            this.cbo조건식매도.Size = new System.Drawing.Size(164, 20);
            this.cbo조건식매도.TabIndex = 31;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button2.Location = new System.Drawing.Point(953, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 27);
            this.button2.TabIndex = 34;
            this.button2.Text = "매수종목갱신";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(10, 172);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(96, 16);
            this.checkBox1.TabIndex = 35;
            this.checkBox1.Text = "개인정보보호";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.button3.Location = new System.Drawing.Point(7, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 28);
            this.button3.TabIndex = 37;
            this.button3.Text = "로그인";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(7, 51);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(101, 28);
            this.button4.TabIndex = 38;
            this.button4.Text = "로그아웃";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(6, 85);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(101, 28);
            this.button5.TabIndex = 39;
            this.button5.Text = "접속상태";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(14, 115);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(85, 26);
            this.button6.TabIndex = 40;
            this.button6.Text = "계 좌 조 회";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightPink;
            this.button7.Location = new System.Drawing.Point(6, 117);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(101, 28);
            this.button7.TabIndex = 41;
            this.button7.Text = "시스템 종료";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(25, 266);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 29);
            this.button8.TabIndex = 42;
            this.button8.Text = "현재가";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(25, 301);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(100, 29);
            this.button9.TabIndex = 43;
            this.button9.Text = "일봉데이터";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(13, 20);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(85, 28);
            this.button10.TabIndex = 44;
            this.button10.Text = "조건식 저장";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(13, 67);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(85, 27);
            this.button11.TabIndex = 45;
            this.button11.Text = "조건식 호출";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(10, 150);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(88, 16);
            this.checkBox2.TabIndex = 46;
            this.checkBox2.Text = "자동 로그인";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Location = new System.Drawing.Point(11, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(116, 191);
            this.groupBox2.TabIndex = 47;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "시스템 접속";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(681, 622);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(143, 52);
            this.button12.TabIndex = 48;
            this.button12.Text = "데이터그리드뷰 초기화";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // btn화면번호초기화
            // 
            this.btn화면번호초기화.Location = new System.Drawing.Point(586, 623);
            this.btn화면번호초기화.Name = "btn화면번호초기화";
            this.btn화면번호초기화.Size = new System.Drawing.Size(91, 50);
            this.btn화면번호초기화.TabIndex = 50;
            this.btn화면번호초기화.Text = "전체화면번호 초기화";
            this.btn화면번호초기화.UseVisualStyleBackColor = true;
            this.btn화면번호초기화.Click += new System.EventHandler(this.btn화면번호초기화_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(50, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(15, 19);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 51;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.종목코드,
            this.종목명,
            this.현재가,
            this.등락률,
            this.거래량,
            this.기호,
            this.보유수량,
            this.매입,
            this.평가금액,
            this.수익률});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Location = new System.Drawing.Point(138, 89);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowHeadersWidth = 21;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(924, 353);
            this.dataGridView1.TabIndex = 27;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            // 
            // 종목코드
            // 
            this.종목코드.HeaderText = "종목코드";
            this.종목코드.Name = "종목코드";
            this.종목코드.Width = 90;
            // 
            // 종목명
            // 
            this.종목명.HeaderText = "종목명";
            this.종목명.Name = "종목명";
            this.종목명.Width = 91;
            // 
            // 현재가
            // 
            this.현재가.HeaderText = "현재가";
            this.현재가.Name = "현재가";
            this.현재가.Width = 90;
            // 
            // 등락률
            // 
            this.등락률.HeaderText = "등락률";
            this.등락률.Name = "등락률";
            this.등락률.Width = 90;
            // 
            // 거래량
            // 
            this.거래량.HeaderText = "거래량";
            this.거래량.Name = "거래량";
            this.거래량.Width = 91;
            // 
            // 기호
            // 
            this.기호.HeaderText = "기호";
            this.기호.Name = "기호";
            this.기호.Width = 90;
            // 
            // 보유수량
            // 
            this.보유수량.HeaderText = "보유수량";
            this.보유수량.Name = "보유수량";
            this.보유수량.Width = 90;
            // 
            // 매입
            // 
            this.매입.HeaderText = "매입가";
            this.매입.Name = "매입";
            this.매입.Width = 90;
            // 
            // 평가금액
            // 
            this.평가금액.HeaderText = "평가금액";
            this.평가금액.Name = "평가금액";
            this.평가금액.Width = 91;
            // 
            // 수익률
            // 
            this.수익률.HeaderText = "수익률";
            this.수익률.Name = "수익률";
            this.수익률.Width = 90;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(619, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 28);
            this.button1.TabIndex = 52;
            this.button1.Text = "예수금";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(842, 58);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 28);
            this.button13.TabIndex = 53;
            this.button13.Text = "손익금";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(731, 58);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(108, 28);
            this.button15.TabIndex = 55;
            this.button15.Text = "유가잔고평가";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox16);
            this.groupBox5.Controls.Add(this.checkBox15);
            this.groupBox5.Controls.Add(this.checkBox13);
            this.groupBox5.Controls.Add(this.checkBox12);
            this.groupBox5.Controls.Add(this.checkBox11);
            this.groupBox5.Controls.Add(this.checkBox10);
            this.groupBox5.Controls.Add(this.checkBox9);
            this.groupBox5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.groupBox5.Location = new System.Drawing.Point(1067, 419);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(243, 162);
            this.groupBox5.TabIndex = 79;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "매도 설정";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(17, 138);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(80, 16);
            this.checkBox16.TabIndex = 71;
            this.checkBox16.Text = "총수익 TS";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(17, 42);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(72, 16);
            this.checkBox15.TabIndex = 70;
            this.checkBox15.Text = "호가매도";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(17, 115);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(84, 16);
            this.checkBox13.TabIndex = 68;
            this.checkBox13.Text = "총수익청산";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(17, 90);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(76, 16);
            this.checkBox12.TabIndex = 67;
            this.checkBox12.Text = "당일 청산";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(17, 65);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(96, 16);
            this.checkBox11.TabIndex = 66;
            this.checkBox11.Text = "트레일링스탑";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(139, 19);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(48, 16);
            this.checkBox10.TabIndex = 65;
            this.checkBox10.Text = "손절";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(17, 20);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(48, 16);
            this.checkBox9.TabIndex = 64;
            this.checkBox9.Text = "익절";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.checkBox3);
            this.groupBox4.Location = new System.Drawing.Point(1068, 230);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(240, 42);
            this.groupBox4.TabIndex = 78;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "자동매매시간";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(125, 14);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(76, 16);
            this.checkBox4.TabIndex = 59;
            this.checkBox4.Text = "종료 시간";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(7, 16);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(76, 16);
            this.checkBox3.TabIndex = 58;
            this.checkBox3.Text = "시작 시간";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox14);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Controls.Add(this.checkBox7);
            this.groupBox3.Controls.Add(this.checkBox6);
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox3.Location = new System.Drawing.Point(1067, 282);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(242, 129);
            this.groupBox3.TabIndex = 77;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "매수 설정";
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(17, 19);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(76, 16);
            this.checkBox14.TabIndex = 69;
            this.checkBox14.Text = "호가 매수";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(17, 107);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(144, 16);
            this.checkBox8.TabIndex = 63;
            this.checkBox8.Text = "미체결 종목 자동 정정";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(17, 85);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(104, 16);
            this.checkBox7.TabIndex = 62;
            this.checkBox7.Text = "중복 매수 금지";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(17, 63);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(112, 16);
            this.checkBox6.TabIndex = 61;
            this.checkBox6.Text = "종목당 투자금액";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(17, 41);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(112, 16);
            this.checkBox5.TabIndex = 60;
            this.checkBox5.Text = "당일매매 종목수";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.richTextBox1.Font = new System.Drawing.Font("새굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox1.Location = new System.Drawing.Point(1068, 620);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(242, 53);
            this.richTextBox1.TabIndex = 76;
            this.richTextBox1.Text = "수익 전광판";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 681);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1338, 22);
            this.statusStrip1.TabIndex = 80;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // btn매도실시간조회
            // 
            this.btn매도실시간조회.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btn매도실시간조회.Location = new System.Drawing.Point(381, 651);
            this.btn매도실시간조회.Name = "btn매도실시간조회";
            this.btn매도실시간조회.Size = new System.Drawing.Size(121, 23);
            this.btn매도실시간조회.TabIndex = 81;
            this.btn매도실시간조회.Text = "실시간조회 [매도]";
            this.btn매도실시간조회.UseVisualStyleBackColor = false;
            this.btn매도실시간조회.Click += new System.EventHandler(this.btn매도실시간조회_Click_1);
            // 
            // lbl코스피
            // 
            this.lbl코스피.AutoSize = true;
            this.lbl코스피.Location = new System.Drawing.Point(6, 687);
            this.lbl코스피.Name = "lbl코스피";
            this.lbl코스피.Size = new System.Drawing.Size(41, 12);
            this.lbl코스피.TabIndex = 82;
            this.lbl코스피.Text = "코스피";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(8, 643);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(119, 31);
            this.button16.TabIndex = 83;
            this.button16.Text = "종합주가지수";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(138, 61);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(100, 27);
            this.button17.TabIndex = 84;
            this.button17.Text = "보유주식현황";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(50, 95);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(15, 19);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 85;
            this.pictureBox2.TabStop = false;
            // 
            // timer2
            // 
            this.timer2.Interval = 10000;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pictureBox2);
            this.groupBox6.Controls.Add(this.pictureBox1);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Location = new System.Drawing.Point(11, 465);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(115, 147);
            this.groupBox6.TabIndex = 86;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "수동진행 ";
            // 
            // lbl현재시간
            // 
            this.lbl현재시간.AutoSize = true;
            this.lbl현재시간.Location = new System.Drawing.Point(1067, 605);
            this.lbl현재시간.Name = "lbl현재시간";
            this.lbl현재시간.Size = new System.Drawing.Size(53, 12);
            this.lbl현재시간.TabIndex = 89;
            this.lbl현재시간.Text = "현재시간";
            // 
            // timer4
            // 
            this.timer4.Enabled = true;
            this.timer4.Interval = 1000;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // lst매수미체결
            // 
            this.lst매수미체결.FormattingEnabled = true;
            this.lst매수미체결.ItemHeight = 12;
            this.lst매수미체결.Location = new System.Drawing.Point(383, 462);
            this.lst매수미체결.Name = "lst매수미체결";
            this.lst매수미체결.Size = new System.Drawing.Size(334, 76);
            this.lst매수미체결.TabIndex = 90;
            // 
            // lst매도미체결
            // 
            this.lst매도미체결.FormattingEnabled = true;
            this.lst매도미체결.ItemHeight = 12;
            this.lst매도미체결.Location = new System.Drawing.Point(723, 462);
            this.lst매도미체결.Name = "lst매도미체결";
            this.lst매도미체결.Size = new System.Drawing.Size(338, 76);
            this.lst매도미체결.TabIndex = 91;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(386, 447);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 92;
            this.label3.Text = "매수[미체결]";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(724, 447);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 93;
            this.label5.Text = "매도[미체결]";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1338, 703);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lst매도미체결);
            this.Controls.Add(this.lst매수미체결);
            this.Controls.Add(this.lbl현재시간);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.lbl코스피);
            this.Controls.Add(this.btn매도실시간조회);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn화면번호초기화);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cbo조건식매도);
            this.Controls.Add(this.검색코드);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btn조건실시간조회);
            this.Controls.Add(this.btn_조건실시간중지);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lst실시간);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cbo조건식);
            this.Controls.Add(this.btn자동주문);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt종목코드);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbo계좌);
            this.Controls.Add(this.lbl아이디);
            this.Controls.Add(this.lbl이름);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.axKHOpenAPI);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "시스템트레이딩 개발을 통해 C#을 배워보자!   키움 자동매매 학습용 프로그램  X-SLON";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl이름;
        private System.Windows.Forms.Label lbl아이디;
        private System.Windows.Forms.ComboBox cbo계좌;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt종목코드;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbo매매구분;
        private System.Windows.Forms.TextBox txt원주문번호;
        private System.Windows.Forms.TextBox txt주문가격;
        private System.Windows.Forms.TextBox txt주문수량;
        private System.Windows.Forms.TextBox txt주문종목코드;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn주문;
        private System.Windows.Forms.ComboBox cbo조건식;
        private System.Windows.Forms.Button btn_조건실시간중지;
        private System.Windows.Forms.Button btn조건실시간조회;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn자동주문;
        private System.Windows.Forms.ListBox lst실시간;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ListBox 검색코드;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbo조건식매도;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btn화면번호초기화;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 종목코드;
        private System.Windows.Forms.DataGridViewTextBoxColumn 종목명;
        private System.Windows.Forms.DataGridViewTextBoxColumn 현재가;
        private System.Windows.Forms.DataGridViewTextBoxColumn 등락률;
        private System.Windows.Forms.DataGridViewTextBoxColumn 거래량;
        private System.Windows.Forms.DataGridViewTextBoxColumn 기호;
        private System.Windows.Forms.DataGridViewTextBoxColumn 보유수량;
        private System.Windows.Forms.DataGridViewTextBoxColumn 매입;
        private System.Windows.Forms.DataGridViewTextBoxColumn 평가금액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 수익률;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.DataGridViewTextBoxColumn 예수금1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 주문가능액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 유가잔고액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 총매수금액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 총매도금액;
        private System.Windows.Forms.DataGridViewTextBoxColumn 매매수수료;
        private System.Windows.Forms.DataGridViewTextBoxColumn 매매세금;
        private System.Windows.Forms.DataGridViewTextBoxColumn 손익금;
        private System.Windows.Forms.DataGridViewTextBoxColumn 당일수익률;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btn매도실시간조회;
        private System.Windows.Forms.Label lbl코스피;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox cbo거래구분;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label lbl현재시간;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.ListBox lst매수미체결;
        private System.Windows.Forms.ListBox lst매도미체결;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
    }
}

